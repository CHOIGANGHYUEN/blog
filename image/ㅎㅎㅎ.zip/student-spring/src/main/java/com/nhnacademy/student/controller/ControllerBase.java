package com.nhnacademy.student.controller;

// marker interface
public interface ControllerBase {

}
