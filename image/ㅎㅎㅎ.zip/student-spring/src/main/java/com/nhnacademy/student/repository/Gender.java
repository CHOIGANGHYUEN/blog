package com.nhnacademy.student.repository;

public enum Gender {
    M,F
}
